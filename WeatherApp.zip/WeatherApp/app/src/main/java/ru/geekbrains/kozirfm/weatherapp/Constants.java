package ru.geekbrains.kozirfm.weatherapp;

public interface Constants {
    String MAIN_CITY = "MAIN_CITY";
    String MAIN_TEMPERATURE = "MAIN_TEMPERATURE";
    String MAIN_WIND_POWER = "MAIN_WIND_POWER";
    String MAIN_PRESSURE = "MAIN_PRESSURE";
    String SELECTED_CITY = "SELECTED_CITY";
    int REQUEST_CODE_SELECTED_CITY_ACTIVITY = 1;
}
